from setuptools import setup

setup(
    name = 'vsearch',
    version ='1.0',
    description = 'The Head First Python search Tools',
    author ='zhengrenwei',
    author_emai ='123@qq.com',
    url = 'headfirsttlabs.com',
    py_modules = ['vsearch'],
)